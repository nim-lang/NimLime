# nimsuggest
idetools for the nim language

## Installation instructions
Clone this repo and `nimble build`.
